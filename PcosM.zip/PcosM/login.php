<?php
session_start();

    $password1 = filter_var($_POST["password1"], FILTER_SANITIZE_STRING);
    $email1 = filter_var($_POST["email1"], FILTER_SANITIZE_STRING);
    $password1 = trim($password1);
    $password1 = stripslashes($password1);
    $password1 = htmlspecialchars($password1);
   
    function pwd_valide($pwd)
    {
        if(strlen ($pwd)<8)
        {
            return false ;
        }
    else if (!preg_match('/[0-9]/',$pwd) ||!preg_match('/[A-Z]/',$pwd) || !preg_match('/[a-z]/',$pwd) || !preg_match('/[*&%$#@!?]/',$pwd))
        {
            return false ;
        }
        else 
        return true;

    }

    
     function email_valide($email)
{
    if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
      return true;
    } 
    else 
        return false;

}  


function loginMember($email, $password)
{
    $passwordHash = md5($password);
    $bdd = new PDO('mysql:host=localhost;dbname=pcosm;charset=utf8', 'root', '');

    $reponse = $bdd->query("SELECT * FROM user WHERE email= '$email' AND password='$passwordHash' AND type_user='client'");
while($donnees= $reponse->fetch())    	 			
{
    return 1;
}
}

   if ($_POST["envoi"]=="log") {
    
    $password1 = filter_var($_POST["password1"], FILTER_SANITIZE_STRING);
    $email1 = filter_var($_POST["email1"], FILTER_SANITIZE_STRING);
  $k=0;
      
    if (pwd_valide($password1) != true)
    {
        echo "Mot de passe non valide!<br>";	
        $k++;
    }
  
     if($k==0)
        {
      if (email_valide($email1) != true)
{
	echo "Email  non valide<br>";	
          $k++;
}

        
        if(    loginMember($email1, $password1)==1)
        {
              $passwordHash = md5($password1);
       $bdd = new PDO('mysql:host=localhost;dbname=pcosm;charset=utf8', 'root', '');
       $reponse = $bdd->query("SELECT * FROM user WHERE email= '$email1' AND password='$passwordHash' AND type_user='client'");
while($donnees= $reponse->fetch())   
{

       $_SESSION["name"] = $donnees['nom_user'];
        $_SESSION["id"] = $donnees['id_user'];
}
                header("Location: index.php");
        }
        
    else{
        echo 'Email ou mot de passe Incorrect';
    }
     }
        } else {
            $errorMessage[] = "User already exists.";
        }

      ?>