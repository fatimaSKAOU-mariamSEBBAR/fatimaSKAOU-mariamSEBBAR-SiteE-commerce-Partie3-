<?php


    $bdd = new PDO('mysql:host=localhost;dbname=pcosm;charset=utf8', 'root', '');

?>